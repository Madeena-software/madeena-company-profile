CREATE TABLE `users` (`id` bigint unsigned not null);
